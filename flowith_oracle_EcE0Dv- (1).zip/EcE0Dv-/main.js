lucide.createIcons();

gsap.registerPlugin(ScrollTrigger);

document.addEventListener("DOMContentLoaded", () => {
    
    const reveals = document.querySelectorAll(".gs-reveal");

    reveals.forEach((elem) => {
        gsap.fromTo(elem, {
            autoAlpha: 0,
            y: 30
        }, {
            duration: 1,
            autoAlpha: 1,
            y: 0,
            ease: "power2.out",
            scrollTrigger: {
                trigger: elem,
                start: "top 85%",
                toggleActions: "play none none none"
            }
        });
    });

    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('shadow-lg');
            navbar.classList.replace('bg-navy-900/95', 'bg-navy-900/100');
        } else {
            navbar.classList.remove('shadow-lg');
            navbar.classList.replace('bg-navy-900/100', 'bg-navy-900/95');
        }
    });

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
});
